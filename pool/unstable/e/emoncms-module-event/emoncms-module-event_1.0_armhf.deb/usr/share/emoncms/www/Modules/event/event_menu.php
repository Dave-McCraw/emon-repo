<?php

  $menu_dropdown[] = array('name'=>"Event", 'path'=>"event" , 'session'=>"write", 'order' => 10 );
