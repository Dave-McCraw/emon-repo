  var widgets = {

    "paragraph": 
    {
      "offsetx":-50,"offsety":-30,"width":100,"height":60,
      "menu":"Text",
      "options":["html"],"optionstype":["html"],"optionsname":["html"],"optionshint":["Html code to show"],"html":
      "Some text"
    },

    "heading": 
    {
      "offsetx":-50,"offsety":-30,"width":100,"height":60,
      "menu":"Text",
      "options":["html"],"optionstype":["html"],"optionsname":["html"],"optionshint":["Html code to show"],"html":
      "Title"
    },

    "heading-center": 
    {
      "offsetx":-50,"offsety":-30,"width":100,"height":60,
      "menu":"Text",
      "options":["html"],"optionstype":["html"],"optionsname":["html"],"optionshint":["Html code to show"],"html":
      "Title"
    },

    "Container-White": 
    {
      "offsetx":0,"offsety":0,"width":200,"height":200,
      "menu":"Containers",
      "html":""
    },

    "Container-Grey": 
    {
      "offsetx":-100,"offsety":-180,"width":200,"height":360,
      "menu":"Containers",
      "html":""
    },

    "Container-Black": 
    {
      "offsetx":-100,"offsety":-180,"width":200,"height":360,
      "menu":"Containers",
      "html":""
    },

    "Container-BlueLine": 
    {
      "offsetx":-100,"offsety":-180,"width":200,"height":360,
      "menu":"Containers",
      "html":""
    }
  };
