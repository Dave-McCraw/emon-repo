# input_queue_processor.php

To be used in association with que_input_controller.php see Modules > Input > readme.md
