<?php

    $schema['myelectric'] = array(
        'userid' => array('type' => 'int(11)'),
        'data' => array('type' => 'text')
    );

?>
