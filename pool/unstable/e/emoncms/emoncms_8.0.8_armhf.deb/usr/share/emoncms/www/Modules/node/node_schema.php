<?php

$schema['node'] = array(
    'userid' => array('type' => 'int(11)'),
    'data' => array('type' => 'text')
);

?>
