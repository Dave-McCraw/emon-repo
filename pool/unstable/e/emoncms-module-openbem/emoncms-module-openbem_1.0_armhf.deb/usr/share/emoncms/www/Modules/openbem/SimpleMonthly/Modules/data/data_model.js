var data_model = 
{
  set_from_inputdata: function (inputdata)
  {
  },
  
  input: {
  
  },

  calc: function() {
  
  }
}

function data_customview()
{
  $("#export").html(JSON.stringify(inputdata, null, 4));
}
