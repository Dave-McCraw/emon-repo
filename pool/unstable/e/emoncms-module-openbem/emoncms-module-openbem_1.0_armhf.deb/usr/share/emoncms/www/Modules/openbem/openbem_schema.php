<?php

  $schema['openbem2'] = array(
    'userid'=> array('type'=>'int(11)','Null'=>'NO'),
    'building'=> array('type'=>'int(11)','Null'=>'NO'),
    'monthly'=> array('type'=>'text'),
    'dynamic'=> array('type'=>'text')
  );

?>
