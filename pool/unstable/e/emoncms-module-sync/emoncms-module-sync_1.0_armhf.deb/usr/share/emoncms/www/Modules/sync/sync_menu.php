<?php

  $menu_dropdown[] = array('name'=>"Sync", 'path'=>"sync/list" , 'session'=>"write", 'order' => 7 );

?>
